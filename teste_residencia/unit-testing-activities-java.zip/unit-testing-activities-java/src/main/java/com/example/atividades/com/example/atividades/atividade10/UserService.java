package com.example.atividades.atividade10;

public class UserService {
    public User getUserInfo(int userId) {
        // Chamar um serviço externo para obter as informações do usuário
        return null;
    }
}
