package com.example.atividades.atividade14;

public class EmailService {
    public void sendEmail(String recipient, String subject, String body) {
        // Enviar email
    }
}