package com.example.atividades.atividade01;

public class Add {
    public int add(int a, int b) {
        return a + b;
    }
}
