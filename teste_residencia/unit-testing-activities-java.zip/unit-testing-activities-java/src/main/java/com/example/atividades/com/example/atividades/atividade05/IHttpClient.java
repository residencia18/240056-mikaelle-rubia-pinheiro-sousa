package com.example.atividades.atividade05;

import java.io.IOException;

public interface IHttpClient {
	String getDataFromApi(String url) throws IOException;
}
