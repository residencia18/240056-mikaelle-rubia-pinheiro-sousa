package com.example.atividades.atividade04;

import java.util.List;
import java.util.Collections;

public class SortNumbers {
    public List<Integer> sortNumbers(List<Integer> numbers) {
        Collections.sort(numbers);
        return numbers;
    }
}
