package com.example.atividades.atividade02;

public class IsEven {
    public boolean isEven(int number) {
        return number % 2 == 0;
    }
}
