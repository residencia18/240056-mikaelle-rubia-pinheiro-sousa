package com.example.atividades.atividade07;

public class Database {
	public void saveUser(User user) {
        // Salvar o usuário no banco de dados
    }
}
