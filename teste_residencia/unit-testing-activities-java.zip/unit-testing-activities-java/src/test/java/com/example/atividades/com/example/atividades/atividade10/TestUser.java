package com.example.atividades.atividade10;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

import com.example.atividades.atividade10.User;

public class TestUser {
	 @Test
	    public void testUserCreation() {
	        String name = "John Doe";
	        String email = "john.doe@example.com";
	        User user = new User(name, email);

	        assertEquals(name, user.getName(), "O nome deve ser 'John Doe'");
	        assertEquals(email, user.getEmail(), "O email deve ser 'john.doe@example.com'");
	    }

	    @Test
	    public void testGetName() {
	        String name = "Alice";
	        String email = "alice@example.com";
	        User user = new User(name, email);
	        
	        assertEquals(name, user.getName(), "O nome deve ser 'Alice'");
	    }

	    @Test
	    public void testGetEmail() {
	        String name = "Bob";
	        String email = "bob@example.com";
	        User user = new User(name, email);
	        
	        assertEquals(email, user.getEmail(), "O email deve ser 'bob@example.com'");
	    }
}
