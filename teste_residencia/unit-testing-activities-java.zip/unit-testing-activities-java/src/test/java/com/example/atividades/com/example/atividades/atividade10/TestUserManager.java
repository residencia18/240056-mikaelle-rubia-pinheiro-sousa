package com.example.atividades.atividade10;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class TestUserManager {
	  private UserManager userManager;
	    private UserService mockUserService;

	    @BeforeEach
	    public void setUp() {
	        mockUserService = Mockito.mock(UserService.class);
	        userManager = new UserManager(mockUserService);
	    }

	    @Test
	    public void testFetchUserInfoSuccess() {
	        int userId = 1;
	        User expectedUser = new User("Jane Doe", "jane.doe@example.com");


	        when(mockUserService.getUserInfo(userId)).thenReturn(expectedUser);

	        User actualUser = userManager.fetchUserInfo(userId);

	        assertEquals(expectedUser, actualUser, "As informa��es do usu�rio devem ser iguais ao esperado");
	    }

	    @Test
	    public void testFetchUserInfoUserNotFound() {
	        int userId = 2;


	        when(mockUserService.getUserInfo(userId)).thenReturn(null);

	        Exception exception = assertThrows(RuntimeException.class, () -> {
	            userManager.fetchUserInfo(userId);
	        });

	        assertEquals("User not found", exception.getMessage(), "A mensagem da exce��o deve ser 'User not found'");
	    }
}
