package com.example.atividades.atividade06;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;


public class TestPoint {
	 @Test
	    public void testDistanceTo() {
	        Point p1 = new Point(0, 0);
	        Point p2 = new Point(3, 4);
	        
	
	        double expected = 5.0;
	        double actual = p1.distanceTo(p2);
	        assertEquals(expected, actual, 0.0001, "A dist�ncia entre (0,0) e (3,4) deve ser 5.0");
	    }

	    @Test
	    public void testDistanceToSamePoint() {
	        Point p1 = new Point(1, 1);

	        double expected = 0.0;
	        double actual = p1.distanceTo(p1);
	        assertEquals(expected, actual, 0.0001, "A dist�ncia entre o ponto e ele mesmo deve ser 0.0");
	    }

	    @Test
	    public void testDistanceToNegativeCoordinates() {
	        Point p1 = new Point(-1, -1);
	        Point p2 = new Point(1, 1);
	        

	        double expected = Math.sqrt(8);
	        double actual = p1.distanceTo(p2);
	        assertEquals(expected, actual, 0.0001, "A dist�ncia entre (-1,-1) e (1,1) deve ser sqrt(8)");
	    }

	    @Test
	    public void testDistanceToNull() {
	        Point p1 = new Point(0, 0);
	        

	        assertThrows(IllegalArgumentException.class, () -> {
	            p1.distanceTo(null);
	        }, "Passar null deve lan�ar IllegalArgumentException");
	    }
}
