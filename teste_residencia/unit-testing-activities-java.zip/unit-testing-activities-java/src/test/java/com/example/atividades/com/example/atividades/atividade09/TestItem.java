package com.example.atividades.atividade09;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNull;

import org.junit.jupiter.api.Test;


public class TestItem {

	 @Test
	    public void testItemCreation() {
	        String name = "Item 01";
	        Item item = new Item(name);
	        assertEquals(name, item.getName(), "O nome deve ser 'Item 01'");
	    }

	    @Test
	    public void testGetName() {
	        String name = "Item 02";
	        Item item = new Item(name);
	        assertEquals(name, item.getName(), "O nome deve ser 'Item 02'");
	    }

	    @Test
	    public void testItemCreationWithEmptyName() {
	        String name = "";
	        Item item = new Item(name);
	        assertEquals(name, item.getName(), "O nome deve ser uma string vazia");
	    }

	    @Test
	    public void testItemCreationWithNullName() {
	        String name = null;
	        Item item = new Item(name);
	        assertNull(item.getName(), "O nome deve ser nulo");
	    }
}
