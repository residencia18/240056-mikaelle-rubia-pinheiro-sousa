package com.example.atividades.atividade13;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class TestFactorial {
	 @Test
	    public void testCalculateWithPositiveNumber() {
	        Factorial factorial = new Factorial();
	        int n = 5;

	        int result = factorial.calculate(n);

	        assertEquals(120, result, "O fatorial de 5 deve ser 120");
	    }

	    @Test
	    public void testCalculateWithZero() {
	        Factorial factorial = new Factorial();
	        int n = 0;

	        int result = factorial.calculate(n);

	        assertEquals(1, result, "O fatorial de 0 deve ser 1");
	    }

	    @Test
	    public void testCalculateWithNegativeNumber() {
	        Factorial factorial = new Factorial();
	        int n = -5;

	        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
	            factorial.calculate(n);
	        });

	        assertEquals("Number must be non-negative", exception.getMessage(), "Uma exce��o deve ser lan�ada para n�meros negativos");
	    }
}
