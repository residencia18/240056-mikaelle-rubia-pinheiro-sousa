package com.example.atividades.atividade11;

import org.junit.jupiter.api.Test;
import java.util.Arrays;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

public class TestCustomSort {
	 @Test
	    public void testCustomSort() {
	        CustomSort customSort = new CustomSort();
	        List<Integer> numbers = Arrays.asList(5, 2, 9, 1, 7);

	        List<Integer> sortedNumbers = customSort.customSort(numbers);

	        List<Integer> expected = Arrays.asList(9, 7, 5, 2, 1);
	        assertEquals(expected, sortedNumbers, "A lista deve estar ordenada em ordem decrescente");
	    }

	    @Test
	    public void testCustomSortWithEmptyList() {
	        CustomSort customSort = new CustomSort();
	        List<Integer> numbers = Arrays.asList();

	        List<Integer> sortedNumbers = customSort.customSort(numbers);

	        assertTrue(sortedNumbers.isEmpty(), "A lista ordenada deve estar vazia");
	    }

	    @Test
	    public void testCustomSortWithSingleElement() {
	        CustomSort customSort = new CustomSort();
	        List<Integer> numbers = Arrays.asList(42);

	        List<Integer> sortedNumbers = customSort.customSort(numbers);

	        List<Integer> expected = Arrays.asList(42);
	        assertEquals(expected, sortedNumbers, "A lista deve conter apenas o n�mero 42");
	    }

	    @Test
	    public void testCustomSortWithDuplicateElements() {
	        CustomSort customSort = new CustomSort();
	        List<Integer> numbers = Arrays.asList(3, 1, 3, 1, 2, 2);

	        List<Integer> sortedNumbers = customSort.customSort(numbers);

	        List<Integer> expected = Arrays.asList(3, 3, 2, 2, 1, 1);
	        assertEquals(expected, sortedNumbers, "A lista deve estar ordenada corretamente mesmo com elementos duplicados");
	    }
}
