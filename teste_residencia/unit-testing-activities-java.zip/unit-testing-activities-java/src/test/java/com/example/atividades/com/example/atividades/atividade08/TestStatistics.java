package com.example.atividades.atividade08;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;


public class TestStatistics {
	@Test
    public void testCalculateAverageWithValidList() {
        Statistics statistics = new Statistics();
        List<Integer> numbers = Arrays.asList(1, 2, 3, 4, 5);

        double expected = 3.0;
        double actual = statistics.calculateAverage(numbers);

        assertEquals(expected, actual, 0.0001, "A m�dia de 1, 2, 3, 4, 5 deve ser 3.0");
    }

    @Test
    public void testCalculateAverageWithNegativeNumbers() {
        Statistics statistics = new Statistics();
        List<Integer> numbers = Arrays.asList(-1, -2, -3, -4, -5);

        double expected = -3.0;
        double actual = statistics.calculateAverage(numbers);

        assertEquals(expected, actual, 0.0001, "A m�dia de -1, -2, -3, -4, -5 deve ser -3.0");
    }

    @Test
    public void testCalculateAverageWithMixedNumbers() {
        Statistics statistics = new Statistics();
        List<Integer> numbers = Arrays.asList(-1, 0, 1);

        double expected = 0.0;
        double actual = statistics.calculateAverage(numbers);

        assertEquals(expected, actual, 0.0001, "A m�dia de -1, 0, 1 deve ser 0.0");
    }

    @Test
    public void testCalculateAverageWithSingleNumber() {
        Statistics statistics = new Statistics();
        List<Integer> numbers = Collections.singletonList(42);

        double expected = 42.0;
        double actual = statistics.calculateAverage(numbers);

        assertEquals(expected, actual, 0.0001, "A m�dia de 42 deve ser 42.0");
    }

    @Test
    public void testCalculateAverageWithEmptyList() {
        Statistics statistics = new Statistics();


        assertThrows(IllegalArgumentException.class, () -> {
            statistics.calculateAverage(Collections.emptyList());
        }, "Esperava IllegalArgumentException quando a lista est� vazia");
    }

    @Test
    public void testCalculateAverageWithNullList() {
        Statistics statistics = new Statistics();


        assertThrows(IllegalArgumentException.class, () -> {
            statistics.calculateAverage(null);
        }, "Esperava IllegalArgumentException quando a lista � nula");
    }
}
