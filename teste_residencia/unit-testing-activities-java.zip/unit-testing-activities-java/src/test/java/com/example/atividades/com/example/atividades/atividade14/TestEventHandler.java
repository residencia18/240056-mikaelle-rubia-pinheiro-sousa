package com.example.atividades.atividade14;

import org.junit.jupiter.api.Test;
import static org.mockito.Mockito.*;

public class TestEventHandler {
	
    @Test
    public void testHandleEvent() {

        EmailService mockEmailService = mock(EmailService.class);
 
        EventHandler eventHandler = new EventHandler(mockEmailService);

        String event = "Test Event";
        eventHandler.handleEvent(event);

        verify(mockEmailService).sendEmail("test@example.com", "Event Occurred", event);
    }
}
