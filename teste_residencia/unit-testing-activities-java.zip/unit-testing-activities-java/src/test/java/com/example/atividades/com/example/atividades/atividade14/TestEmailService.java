package com.example.atividades.atividade14;

import org.junit.jupiter.api.Test;
import org.mockito.ArgumentCaptor;

import static org.junit.jupiter.api.Assertions.assertAll;
import static org.junit.jupiter.api.Assertions.assertEquals; 
import static org.mockito.Mockito.*;

public class TestEmailService {
	 @Test
	    public void testSendEmail() {
	        EmailService emailService = mock(EmailService.class);


	        ArgumentCaptor<String> recipientCaptor = ArgumentCaptor.forClass(String.class);
	        ArgumentCaptor<String> subjectCaptor = ArgumentCaptor.forClass(String.class);
	        ArgumentCaptor<String> bodyCaptor = ArgumentCaptor.forClass(String.class);


	        emailService.sendEmail("recipient@example.com", "Test Subject", "Test Body");


	        verify(emailService).sendEmail(recipientCaptor.capture(), subjectCaptor.capture(), bodyCaptor.capture());


	        String capturedRecipient = recipientCaptor.getValue();
	        String capturedSubject = subjectCaptor.getValue();
	        String capturedBody = bodyCaptor.getValue();


	        assertAll("Verificar argumentos",
	                () -> assertEquals("recipient@example.com", capturedRecipient, "O destinat�rio deve ser 'recipient@example.com'"),
	                () -> assertEquals("Test Subject", capturedSubject, "O assunto deve ser 'Test Subject'"),
	                () -> assertEquals("Test Body", capturedBody, "O corpo deve ser 'Test Body'")
	        );
	    }
}
