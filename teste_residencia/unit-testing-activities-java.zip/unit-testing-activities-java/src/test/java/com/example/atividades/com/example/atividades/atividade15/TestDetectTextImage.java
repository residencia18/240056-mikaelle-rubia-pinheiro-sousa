package com.example.atividades.atividade15;

import org.junit.jupiter.api.Test;
import software.amazon.awssdk.services.rekognition.RekognitionClient;
import software.amazon.awssdk.services.rekognition.model.*;

import java.util.ArrayList;
import java.util.List;

import static org.mockito.Mockito.*;

public class TestDetectTextImage {

    @Test
    public void testDetectTextLabels() {

        RekognitionClient rekClientMock = mock(RekognitionClient.class);


        DetectTextImage detectTextImage = new DetectTextImage("../../../../com/example/atividades/atividade15/img-example-for-aws-task.jpg", rekClientMock);


        List<TextDetection> textDetections = new ArrayList<>();
        textDetections.add(TextDetection.builder()
                .detectedText("Text 1")
                .confidence(99.9f)
                .id(1)
                .parentId(0)
                .type(TextTypes.LINE)
                .build());
        textDetections.add(TextDetection.builder()
                .detectedText("Text 2")
                .confidence(98.7f)
                .id(2)
                .parentId(0)
                .type(TextTypes.LINE)
                .build());


        DetectTextResponse detectTextResponse = DetectTextResponse.builder()
                .textDetections(textDetections)
                .build();
        when(rekClientMock.detectText(any(DetectTextRequest.class))).thenReturn(detectTextResponse);
        

        detectTextImage.detectTextLabels("output.txt");

 
        verify(rekClientMock, times(1)).detectText(any(DetectTextRequest.class));
    
        
    }
}
