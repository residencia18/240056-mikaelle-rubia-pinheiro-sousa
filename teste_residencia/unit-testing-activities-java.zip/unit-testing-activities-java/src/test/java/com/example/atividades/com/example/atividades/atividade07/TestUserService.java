package com.example.atividades.atividade07;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;

import com.example.atividades.atividade07.Database;
import com.example.atividades.atividade07.User;
import com.example.atividades.atividade07.UserService;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class TestUserService {
    private Database db;
    private UserService userService;

    @BeforeEach
    public void setUp() {
        db = Mockito.mock(Database.class);
        userService = new UserService(db);
    }

    @Test
    public void testSaveUserSuccess() {
        User user = new User("John Doe", "john.doe@example.com");

        userService.saveUser(user);

        verify(db, times(1)).saveUser(user);
    }

    @Test
    public void testSaveUserNullName() {
        User user = new User(null, "john.doe@example.com");

        assertThrows(IllegalArgumentException.class, () -> {
            userService.saveUser(user);
        }, "Esperava IllegalArgumentException quando o nome � nulo");
    }

    @Test
    public void testSaveUserEmptyName() {
        User user = new User("", "john.doe@example.com");

        assertThrows(IllegalArgumentException.class, () -> {
            userService.saveUser(user);
        }, "Esperava IllegalArgumentException quando o nome est� vazio");
    }

    @Test
    public void testSaveUserNullEmail() {
        User user = new User("John Doe", null);

        assertThrows(IllegalArgumentException.class, () -> {
            userService.saveUser(user);
        }, "Esperava IllegalArgumentException quando o email � nulo");
    }

    @Test
    public void testSaveUserEmptyEmail() {
        User user = new User("John Doe", "");

        assertThrows(IllegalArgumentException.class, () -> {
            userService.saveUser(user);
        }, "Esperava IllegalArgumentException quando o email est� vazio");
    }
}
